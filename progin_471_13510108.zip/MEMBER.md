No NIM         Name                          GitHub_ID            Mail
1  13510008    Mohammad Anugrah Sulaeman     anugrahsulaeman      anugrahsulaeman17@gmail.com
2  13510086    Sharon Loh                    sharonloh		  		lohh.sharon@gmail.com
3  13510096    Ruth Nattassha                MidnightStar69			salvaterarug@gmail.com 