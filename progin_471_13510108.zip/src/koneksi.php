<?php
$conn=mysql_connect("localhost", "progin", "progin");
mysql_select_db("progin_405_13510108");
?> 